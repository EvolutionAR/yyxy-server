# {comName}

组件中文名：{comCnName}

组件描述：{comDesc}