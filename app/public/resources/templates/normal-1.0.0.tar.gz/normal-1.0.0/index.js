/**
 * 导出组件，勿删勿改！！！！！！！
 */
import Main from './src/main.vue';

export default Main;