<template>
  <div class="my-chart">
    {{ name }}
  </div>
</template>

<script>
/**
 * 组件定义
 *【vue组件使用文档(V2.x)】 https://cn.vuejs.org/
 *【属性说明】： id、config、data
 * 这些属性通过 props 透传进来，开发者可以通过 `this.[属性名]` 访问。
 * 注：【开发者只能读取，切勿修改和覆盖这些属性】
 */
export default {
  data() {
    return {
      name: '{comCnName}' // 测试用，可删除
    };
  },

  methods: {
    /**
     * 初始化方法【必选】
     * 会在 vue 生命周期的 mounted 阶段调用
    */
    init () {
      /** write your code */
    },
    /**
     * 渲染组件【必选】
     * 当组件被初始化后，组件渲染逻辑被调用。
     */
    render () {
      /** write your code */
      // 可通过 `this.config this.data` 读取配置和数据
    },
    /**
     * 自适应尺寸【可选】
     * 当组件被拖拽、缩放时被调用。
     */
    resize ({ width, height }) {
      /** write your code */
    },
    /**
     * 清理组件，只清空画布，组件实例保留【可选】
     * 当组件被清理时调用
     */
    clear () {
      /** write your code */
    },
    /**
     * 销毁组件，彻底销毁，组件实例不可用【可选】
     * 组件被销毁时调用，会在 vue 组件声明周期勾子 beforeDestroy 里调用
     */
    destroy () {
      /** write your code */
    },
    /**
     * 组件内置，不可在此处覆盖的方法
     * emit(eventName, data)：抛出事件。开发者可以调用，勿改勿覆盖
     * on(compId, eventName, callback)：此组件监听来自其他组件的事件。组件内部调用，勿改勿覆盖
     * off(compId, eventName, callback)：移除监听。组件内部调用，勿改勿覆盖
     */
  }
}
</script>

<style scoped>
/**
 在此处添加组件 css 样式（用 scoped 声明隔离其他组件样式，支持纯css、scss、less。）
 注：组件根元素的宽高系统自动设定，不需在此写死宽高，此处宽高用百分比适配。
 */
</style>